-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2019 at 07:28 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `bigdatas`
--

CREATE TABLE `bigdatas` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `col2` varchar(255) DEFAULT NULL,
  `col3` varchar(255) DEFAULT NULL,
  `col4` varchar(255) DEFAULT NULL,
  `col5` varchar(255) DEFAULT NULL,
  `col6` varchar(255) DEFAULT NULL,
  `col7` varchar(255) DEFAULT NULL,
  `col8` varchar(255) DEFAULT NULL,
  `col9` varchar(255) DEFAULT NULL,
  `col10` varchar(14) DEFAULT NULL,
  `col11` varchar(255) DEFAULT NULL,
  `col12` varchar(255) DEFAULT NULL,
  `col13` varchar(100) DEFAULT NULL,
  `col14` varchar(255) DEFAULT NULL,
  `col15` varchar(255) DEFAULT NULL,
  `col16` varchar(255) DEFAULT NULL,
  `col17` varchar(255) DEFAULT NULL,
  `col18` varchar(255) DEFAULT NULL,
  `col19` varchar(255) DEFAULT NULL,
  `col20` varchar(255) DEFAULT NULL,
  `col21` varchar(255) DEFAULT NULL,
  `col22` varchar(255) DEFAULT NULL,
  `col23` varchar(255) DEFAULT NULL,
  `col24` varchar(255) DEFAULT NULL,
  `col25` varchar(255) DEFAULT NULL,
  `col26` varchar(255) DEFAULT NULL,
  `col27` varchar(255) DEFAULT NULL,
  `col28` varchar(255) DEFAULT NULL,
  `col29` varchar(255) DEFAULT NULL,
  `col30` varchar(255) DEFAULT NULL,
  `col31` varchar(255) DEFAULT NULL,
  `col32` varchar(255) DEFAULT NULL,
  `col33` varchar(255) DEFAULT NULL,
  `col34` varchar(255) DEFAULT NULL,
  `col35` varchar(255) DEFAULT NULL,
  `col36` varchar(255) DEFAULT NULL,
  `col37` varchar(255) DEFAULT NULL,
  `col38` varchar(255) DEFAULT NULL,
  `col39` varchar(255) DEFAULT NULL,
  `col40` varchar(255) DEFAULT NULL,
  `col41` varchar(255) DEFAULT NULL,
  `col42` varchar(255) DEFAULT NULL,
  `col43` varchar(255) DEFAULT NULL,
  `col44` varchar(255) DEFAULT NULL,
  `col45` varchar(255) DEFAULT NULL,
  `col46` varchar(255) DEFAULT NULL,
  `col47` varchar(255) DEFAULT NULL,
  `col48` varchar(255) DEFAULT NULL,
  `col49` varchar(255) DEFAULT NULL,
  `col50` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(5, '2014_10_12_000000_create_users_table', 1),
(6, '2014_10_12_100000_create_password_resets_table', 1),
(7, '2019_08_19_000000_create_failed_jobs_table', 1),
(8, '2019_12_18_151732_create_databigs_table', 1),
(9, '2019_12_19_011959_create_pages_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `col2` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col3` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col4` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col5` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col6` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col7` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col8` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col9` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `col10` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col11` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col12` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col13` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col14` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col15` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col16` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col17` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col18` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col19` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col20` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col21` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col22` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col23` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col24` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col25` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col26` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col27` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col28` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col29` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col30` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col31` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col32` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col33` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col34` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col35` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col36` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col37` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col38` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col39` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col40` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col41` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col42` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col43` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col44` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col45` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col46` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col47` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col48` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `col49` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `col2`, `col3`, `col4`, `col5`, `col6`, `col7`, `col8`, `col9`, `col10`, `col11`, `col12`, `col13`, `col14`, `col15`, `col16`, `col17`, `col18`, `col19`, `col20`, `col21`, `col22`, `col23`, `col24`, `col25`, `col26`, `col27`, `col28`, `col29`, `col30`, `col31`, `col32`, `col33`, `col34`, `col35`, `col36`, `col37`, `col38`, `col39`, `col40`, `col41`, `col42`, `col43`, `col44`, `col45`, `col46`, `col47`, `col48`, `col49`, `created_at`, `updated_at`) VALUES
(8, 'dasf', 'weherh', 'dgdg', 'erhre', 'gweg', 'hdfhdf', 'egewg', 'fhdfh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'fgg', 'erher', 'sdgr', 'erher', 'ererh', 'ererj', 'erjherjh', 'erj', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'g5h', 'j45j', '54j45j', '54j45j', '45j45', '57j', 'j45j54', '56j', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'regry', 'iii56', '6uj', '56i56i', '6i65i', '5ioi', '56i56', 'i656i', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'o78o', '78p', '78o78', 'r5o67o', '78p78p', '67o67ro', '78p78p', '67ro67o', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, '7o67o', 'o67o', '67or56', '67o67o', '5e6i9', '67ro', 'io56o67', '67o67ro', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, '76o67o', '76o67eo', '67o67', 'e67oe67', 'or67o67o', 'o67o', '67o67eo', 'e67oe7o', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, '76eoe76o', 'e6o67o', 'e7oe67o', 'e67o76o', 'e67o67eo', 'e67o', 'e67o7', '67oe67', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '7eo76o', '67oe67o', '67oe67', 'e67o76', 'o67o', '67oe67', 'e76o7', '6e7o', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 'eo67o', '67eo67', 'e76o67', 'e67o67', 'e67o7', 'e67o', 'e67o', 'e68o', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, '6u86u', 'w6i4w6i', '56ui56ui', '6wi', '56i6i', '6wi6', '6wiw6', 'i6wi', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 'safsafas', 'asfsf', 'fasfasf', 'asfasf', 'safasf', 'asfasf', 'asfasf', 'asfasf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 'asfgwetg', 'wegwe', 'wegweg', 'gweg', 'wegweg', 'wegweg', 'wegweg', 'wegweg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bigdatas`
--
ALTER TABLE `bigdatas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bigdatas`
--
ALTER TABLE `bigdatas`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
