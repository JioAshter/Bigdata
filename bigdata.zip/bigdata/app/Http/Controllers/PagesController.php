<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Exports\PagessExport;
use Maatwebsite\Excel\Facades\Excel;

class PagesController extends Controller
{
    public function index()
    {
    	$data = \App\Pages::all();
    	return view('welcome', ['data' => $data]);
    }

    public function tambah()
    {
    	return view('tambahdata');
    }

    public function simpan(Request $request)
    {
    	DB::table('pages')->insert([
			'col2' => $request->col2,
    		'col3' => $request->col3,
    		'col4' => $request->col4,
    		'col5' => $request->col5,
    		'col6' => $request->col6,
    		'col7' => $request->col7,
    		'col8' => $request->col8,
    		'col9' => $request->col9
		]);

		return redirect('/');
    }

    public function hapus($id)
	{
		DB::table('pages')->where('id',$id)->delete();
			
		return redirect('/');
	}

	public function edit($id)
	{
	
		$data = \App\Pages::find($id);
		return view('editdata',['data' => $data]);
	 
	}

	public function update(Request $request,$id)
	{
		$data = \App\Pages::find($id);
		$data->update($request->all());
		return redirect('/');
	}

	public function export() 
    {
        
        return Excel::download(new PagessExport, 'Bigdata.csv');
    }
}
