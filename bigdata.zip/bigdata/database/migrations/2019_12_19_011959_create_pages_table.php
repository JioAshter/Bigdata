<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('col2',20);
            $table->string('col3',20);
            $table->string('col4',20);
            $table->string('col5',20);
            $table->string('col6',20);
            $table->string('col7',20);
            $table->string('col8',20);
            $table->string('col9',20);
            $table->string('col10',20);
            $table->string('col11',20);
            $table->string('col12',20);
            $table->string('col13',20);
            $table->string('col14',20);
            $table->string('col15',20);
            $table->string('col16',20);
            $table->string('col17',20);
            $table->string('col18',20);
            $table->string('col19',20);
            $table->string('col20',20);
            $table->string('col21',20);
            $table->string('col22',20);
            $table->string('col23',20);
            $table->string('col24',20);
            $table->string('col25',20);
            $table->string('col26',20);
            $table->string('col27',20);
            $table->string('col28',20);
            $table->string('col29',20);
            $table->string('col30',20);
            $table->string('col31',20);
            $table->string('col32',20);
            $table->string('col33',20);
            $table->string('col34',20);
            $table->string('col35',20);
            $table->string('col36',20);
            $table->string('col37',20);
            $table->string('col38',20);
            $table->string('col39',20);
            $table->string('col40',20);
            $table->string('col41',20);
            $table->string('col42',20);
            $table->string('col43',20);
            $table->string('col44',20);
            $table->string('col45',20);
            $table->string('col46',20);
            $table->string('col47',20);
            $table->string('col48',20);
            $table->string('col49',20);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pages');
    }
}
