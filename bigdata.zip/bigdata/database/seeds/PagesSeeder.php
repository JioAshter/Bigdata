<?php

use Illuminate\Database\Seeder;

class PagesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
 
    	for($i = 1; $i <= 100; $i++){
 
    	      // insert data ke table menggunakan Faker
    		DB::table('pages')->insert([
    			'col2' => $faker->jobTitle,
    			'col3' => $faker->name,
    			'col4' => $faker->address,
    			'col5' => $faker->name,
    			'col6' => $faker->name,
    			'col7' => $faker->name,
    			'col8' => $faker->name,
    			'col9' => $faker->name,
    			'col10' => $faker->name,
    			'col11' => $faker->name,
    			'col12' => $faker->name,
    			'col13' => $faker->name,
    			'col14' => $faker->name,
    			'col15' => $faker->name,
    			'col16' => $faker->name,
    			'col17' => $faker->name,
    			'col18' => $faker->name,
    			'col19' => $faker->name,
    			'col20' => $faker->name,
    			'col21' => $faker->name,
    			'col22' => $faker->name,
    			'col23' => $faker->name,
    			'col24' => $faker->name,
    			'col25' => $faker->name,
    			'col26' => $faker->name,
    			'col27' => $faker->name,
    			'col28' => $faker->name,
    			'col29' => $faker->name,
    			'col30' => $faker->name,
    			'col31' => $faker->name,
    			'col32' => $faker->name,
    			'col33' => $faker->name,
    			'col34' => $faker->name,
    			'col35' => $faker->name,
    			'col36' => $faker->name,
    			'col37' => $faker->name,
    			'col38' => $faker->name,
    			'col39' => $faker->name,
    			'col40' => $faker->name,
    			'col41' => $faker->name,
    			'col42' => $faker->name,
    			'col43' => $faker->name,
    			'col44' => $faker->name,
    			'col45' => $faker->name,
    			'col46' => $faker->name,
    			'col47' => $faker->name,
    			'col48' => $faker->name,
    			'col49' => $faker->name,
    			'col50' => $faker->jobTitle
    		]);
 
    	}
    }
}
